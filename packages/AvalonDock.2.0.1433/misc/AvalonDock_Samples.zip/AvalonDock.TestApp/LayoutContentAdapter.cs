﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using AvalonDock.Layout;

namespace AvalonDock.TestApp
{
    public class LayoutContentAdapter : DependencyObject
    {

        #region Title

        /// <summary>
        /// Title Attached Dependency Property
        /// </summary>
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.RegisterAttached("Title", typeof(string), typeof(LayoutContentAdapter),
                new FrameworkPropertyMetadata((string)null,
                    new PropertyChangedCallback(OnTitleChanged)));

        /// <summary>
        /// Gets the Title property.  This dependency property 
        /// indicates the title to get or set.
        /// </summary>
        public static string GetTitle(DependencyObject d)
        {
            return (string)d.GetValue(TitleProperty);
        }

        /// <summary>
        /// Sets the Title property.  This dependency property 
        /// indicates the title to get or set.
        /// </summary>
        public static void SetTitle(DependencyObject d, string value)
        {
            d.SetValue(TitleProperty, value);
        }

        /// <summary>
        /// Handles changes to the Title property.
        /// </summary>
        private static void OnTitleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            LayoutContent layoutContent = d as LayoutContent;
            if (layoutContent != null)
                layoutContent.Title = (string)e.NewValue;
        }

        #endregion




    }
}
